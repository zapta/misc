
def lib_func(msg:str)->None:
    print(f"*** lib_func(): {msg}")