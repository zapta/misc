#!/bin/bash

# export PYTHONPATH="..:$PYTHONPATH"

python myapp/main.py



