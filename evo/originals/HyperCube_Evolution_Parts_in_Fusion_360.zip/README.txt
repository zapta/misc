                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2937693
HyperCube Evolution Parts in Fusion 360 by akira3dp0 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

***<UPDATE August 25,2018>***
I added some non-printed parts.
  Aluminum extruisons (2020,3030), Linear rail, Linear bearings, NEMA17 stepper motor.

***<UPDATE June 1,2018>***
"X Carriage" was update. Bcause there were not holes for dowel pins.

***< SUMMARY >***
In Autodesk Fusion 360, I made all parts that I need for double Z type of [HyperCube Evolution](https://www.thingiverse.com/thing:2254103 "HyperCube Evolution by SCOTT_3D - Thingiverse"). Because I wanted to adjust the margin for linear shafts and the difference of a standard for aluminum extrusions.
You can easily modify and adjust the parts, if you are a Autodesk Fusion 360 user. Of course there are included the design history.
If you want another parts, please tell me. I will add the parts.
(But I am a novice for Fusion 360, sorry:) )
Thanks for [SCOTT_3D](https://www.thingiverse.com/SCOTT_3D/about "About SCOTT_3D - Thingiverse") and HyperCube Evolution users.